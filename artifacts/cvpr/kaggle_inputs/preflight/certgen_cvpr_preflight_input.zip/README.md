CertGen Phase 1 preflight static input. not_empirical_evidence; claim_allowed=false.
