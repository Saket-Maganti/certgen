"""Optional feature-extraction stubs."""
