"""Decision certificate helpers."""
