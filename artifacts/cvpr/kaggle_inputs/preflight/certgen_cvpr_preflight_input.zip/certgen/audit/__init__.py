"""Audit commands for CertGen."""
