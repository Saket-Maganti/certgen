"""Core utilities for CertGen."""
