"""Report rendering helpers."""
