"""Pilot planning helpers."""
