One active subprocess worker per physical GPU; multiprocessing spawn; hash-safe completion markers; atomic shards; claim_allowed=false.
