# CertGen preflight Kaggle input

Select GPU T4 x2. Validate locally with:

`python3 -m certgen kaggle validate-input artifacts/cvpr/kaggle_inputs/preflight/certgen_cvpr_preflight_input.zip`

Upload this ZIP without unpacking. Run `notebooks/kaggle/certgen_cvpr_checkpoint_preflight_t4x2.ipynb`. Download the final output ZIP and place it under `data/kaggle_returns/preflight/`, then run:

`CUDA_VISIBLE_DEVICES="" CERTGEN_CPU_ONLY=1 python3 scripts/run_all_available_cpu_stages.py --resume --explain`

This package contains no credentials or model weights. `claim_allowed=false`.
