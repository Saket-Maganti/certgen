CertGen Phase 1 diagnostic static input. not_empirical_evidence; claim_allowed=false.
